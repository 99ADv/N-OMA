export interface notification {
    modal: string,
    type_of_message: string,
    message: string
}