export const environment = {
  production: true,
  api_url: 'http://161.35.62.68:3000/api/oa/v1/',
  path: '/api/oa/v1/socket.io',
  api_ws: 'http://161.35.62.68:3000'
};
