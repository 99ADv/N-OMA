export const environment = {
  production: true,
  api_url: 'https://db70-191-95-154-91.ngrok.io/api/oa/v1/',
  path: '/api/oa/v1/socket.io',
  api_ws: 'https://db70-191-95-154-91.ngrok.io'
};
