import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-call',
  templateUrl: './new-call.component.html',
  styleUrls: ['./new-call.component.scss'],
})
export class NewCallComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
