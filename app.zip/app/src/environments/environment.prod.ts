export const environment = {
  production: true,
  api_url: 'https://api-n-oma.herokuapp.com/api/oa/v1/',
  path: '/api/oa/v1/socket.io',
  api_ws: 'https://api-n-oma.herokuapp.com/'
};
